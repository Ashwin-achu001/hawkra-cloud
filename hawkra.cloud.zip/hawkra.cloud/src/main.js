/**
 * Hawkra Cloud — Production Interactive Controller
 * Lightweight, accessible, and robust functionality.
 */

document.addEventListener('DOMContentLoaded', () => {
  initScrollReveal();
  initMobileMenu();
  initSmoothScrolling();
  initConsoleSidebar();
  initDeveloperTabs();
  initCopySnippet();
  initOnboardingForm();
  initBenchmarkSimulator();
  initEdgeRegions();
  initConsoleActions();
  initConfigBuilder();
  initGetStartedLaunchpad();
  updateFooterYear();
});

/* --------------------------------------------------------------------------
   1. Subtle Scroll Reveal
   -------------------------------------------------------------------------- */
function initScrollReveal() {
  const elements = document.querySelectorAll('.fade-in');
  
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.08,
      rootMargin: '0px 0px -20px 0px'
    });

    elements.forEach(el => observer.observe(el));
  } else {
    elements.forEach(el => el.classList.add('visible'));
  }
}

/* --------------------------------------------------------------------------
   2. Mobile Drawer Navigation
   -------------------------------------------------------------------------- */
function initMobileMenu() {
  const toggle = document.getElementById('mobile-toggle');
  const drawer = document.getElementById('mobile-nav');

  if (!toggle || !drawer) return;

  function toggleDrawer() {
    const isOpen = toggle.classList.toggle('active');
    drawer.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(isOpen));
    drawer.setAttribute('aria-hidden', String(!isOpen));

    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }

  toggle.addEventListener('click', toggleDrawer);

  // Close when clicking inside mobile navigation links
  const links = drawer.querySelectorAll('a');
  links.forEach(link => {
    link.addEventListener('click', () => {
      if (drawer.classList.contains('open')) {
        toggleDrawer();
      }
    });
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && drawer.classList.contains('open')) {
      toggleDrawer();
    }
  });
}

/* --------------------------------------------------------------------------
   3. Smooth Scrolling for Internal Navigation Anchors
   -------------------------------------------------------------------------- */
function initSmoothScrolling() {
  const anchorLinks = document.querySelectorAll('a[href^="#"], a[href^="/#"]');

  anchorLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      const rawHref = link.getAttribute('href');
      if (!rawHref) return;

      const hashIndex = rawHref.indexOf('#');
      if (hashIndex === -1) return;
      
      const targetId = rawHref.substring(hashIndex);
      if (!targetId || targetId === '#') return;

      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        e.preventDefault();

        const headerOffset = 70;
        const elementPosition = targetEl.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        window.scrollTo({
          top: targetId === '#hero' ? 0 : offsetPosition,
          behavior: 'smooth'
        });

        if (history.pushState) {
          history.pushState(null, '', targetId);
        }
      }
    });
  });
}

/* --------------------------------------------------------------------------
   4. Platform Console Sidebar View Switcher
   -------------------------------------------------------------------------- */
function initConsoleSidebar() {
  const sidebarItems = document.querySelectorAll('.sb-item');
  const views = document.querySelectorAll('.console-view');

  sidebarItems.forEach(item => {
    item.addEventListener('click', () => {
      const targetViewId = item.getAttribute('data-view');
      if (!targetViewId) return;

      sidebarItems.forEach(btn => btn.classList.remove('active'));
      item.classList.add('active');

      views.forEach(view => {
        if (view.id === targetViewId) {
          view.classList.add('active');
        } else {
          view.classList.remove('active');
        }
      });
    });
  });
}

/* --------------------------------------------------------------------------
   5. Developer Terminal Code Tabs
   -------------------------------------------------------------------------- */
function initDeveloperTabs() {
  const tabBtns = document.querySelectorAll('.t-btn');
  const codePanes = document.querySelectorAll('.code-view-pane');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      if (!targetId) return;

      tabBtns.forEach(b => {
        b.classList.remove('active');
        b.setAttribute('aria-selected', 'false');
      });
      btn.classList.add('active');
      btn.setAttribute('aria-selected', 'true');

      codePanes.forEach(pane => {
        if (pane.id === targetId) {
          pane.classList.add('active');
        } else {
          pane.classList.remove('active');
        }
      });
    });
  });
}

/* --------------------------------------------------------------------------
   6. Developer Terminal Copy Snippet
   -------------------------------------------------------------------------- */
function initCopySnippet() {
  const copyButtons = document.querySelectorAll('.copy-trigger-btn');

  copyButtons.forEach(copyBtn => {
    copyBtn.addEventListener('click', async () => {
      let text = copyBtn.getAttribute('data-copy');

      if (!text) {
        let codeEl = null;
        const parentContainer = copyBtn.closest('.terminal-install-box, .dark-terminal-box, .lp-generated-code-box');
        
        if (parentContainer) {
          codeEl = parentContainer.querySelector('code');
        }
        
        if (!codeEl) {
          const activePane = document.querySelector('.code-view-pane.active');
          if (activePane) {
            codeEl = activePane.querySelector('code');
          }
        }

        text = codeEl ? codeEl.innerText : '';
      }

      if (!text) return;

      try {
        await navigator.clipboard.writeText(text);

        const copyIco = copyBtn.querySelector('.copy-ico');
        const checkIco = copyBtn.querySelector('.check-ico');
        const textSpan = copyBtn.querySelector('.copy-text') || copyBtn;

        if (copyIco && checkIco) {
          copyIco.classList.add('hidden');
          checkIco.classList.remove('hidden');
        }

        const originalText = textSpan.textContent;
        textSpan.textContent = 'Copied ✔';

        setTimeout(() => {
          if (copyIco && checkIco) {
            copyIco.classList.remove('hidden');
            checkIco.classList.add('hidden');
          }
          textSpan.textContent = originalText;
        }, 2000);
      } catch (err) {
        console.error('Failed to copy code snippet: ', err);
      }
    });
  });
}

/* --------------------------------------------------------------------------
   7. Onboarding Form Submission Handler (/get-started)
   -------------------------------------------------------------------------- */
function initOnboardingForm() {
  const form = document.getElementById('workspace-form');
  const feedback = document.getElementById('form-feedback');
  const submitBtn = document.getElementById('submit-workspace-btn');

  if (!form || !feedback || !submitBtn) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span>Initializing Workspace...</span>';

    setTimeout(() => {
      feedback.classList.remove('hidden');
      submitBtn.innerHTML = '<span>Workspace Initialized ✔</span>';
    }, 500);
  });
}

/* --------------------------------------------------------------------------
   8. Interactive MicroVM Benchmark Simulator
   -------------------------------------------------------------------------- */
function initBenchmarkSimulator() {
  const slider = document.getElementById('bench-slider');
  const valDisplay = document.getElementById('bench-slider-val');
  const instancesEl = document.getElementById('bench-instances-val');
  const latencyEl = document.getElementById('bench-latency-val');
  const memoryEl = document.getElementById('bench-memory-val');
  const coldBootEl = document.getElementById('bench-coldboot-val');
  const fillBar = document.getElementById('vis-fill-bar');
  const barText = document.getElementById('vis-bar-text');
  const btnBootTest = document.getElementById('btn-boot-test');
  const btnSpikeTest = document.getElementById('btn-spike-test');
  const statusBadge = document.getElementById('bench-status-badge');

  if (!slider) return;

  function updateMetrics(concurrency) {
    const instances = Math.max(1, Math.ceil(concurrency / 250));
    const p99 = (3.2 + (concurrency / 30000) * 3.4).toFixed(1);
    const mem = Math.round(instances * 18);
    const pct = Math.min(100, Math.max(8, (concurrency / 50000) * 100));

    if (valDisplay) valDisplay.textContent = Number(concurrency).toLocaleString() + ' req/s';
    if (instancesEl) instancesEl.textContent = instances + ' MicroVMs';
    if (latencyEl) latencyEl.textContent = p99 + 'ms (p99)';
    if (memoryEl) memoryEl.textContent = mem + ' MB';
    if (fillBar) fillBar.style.width = pct + '%';
    if (barText) barText.textContent = instances + ' instances active';
  }

  slider.addEventListener('input', (e) => {
    updateMetrics(Number(e.target.value));
  });

  if (btnBootTest) {
    btnBootTest.addEventListener('click', () => {
      btnBootTest.disabled = true;
      btnBootTest.textContent = 'Measuring Cold Boot...';
      if (statusBadge) statusBadge.innerHTML = '<span class="status-indicator-dot"></span><span>Spawning Kernel Sandbox...</span>';
      
      let start = 0;
      const interval = setInterval(() => {
        start += 1.2;
        if (coldBootEl) coldBootEl.textContent = start.toFixed(1) + 'ms';
        if (start >= 12.4) {
          clearInterval(interval);
          if (coldBootEl) coldBootEl.textContent = '12.4ms';
          btnBootTest.disabled = false;
          btnBootTest.textContent = '▶ Run MicroVM Boot Test';
          if (statusBadge) statusBadge.innerHTML = '<span class="status-indicator-dot"></span><span>Verified: 12.4ms Boot (Linux KVM Guest)</span>';
        }
      }, 30);
    });
  }

  if (btnSpikeTest) {
    btnSpikeTest.addEventListener('click', () => {
      slider.value = 35000;
      updateMetrics(35000);
      if (statusBadge) statusBadge.innerHTML = '<span class="status-indicator-dot"></span><span>Spike Absorbed: 140 MicroVMs Scaled in 18ms</span>';
    });
  }
}

/* --------------------------------------------------------------------------
   9. Global Anycast Edge Region Switcher
   -------------------------------------------------------------------------- */
function initEdgeRegions() {
  const regionBtns = document.querySelectorAll('.edge-region-btn');
  const panelTitle = document.getElementById('tel-region-title');
  const panelPing = document.getElementById('tel-region-ping');
  const panelNodes = document.getElementById('tel-region-nodes');
  const panelAnycast = document.getElementById('tel-region-anycast');
  const panelBw = document.getElementById('tel-region-bw');

  if (!regionBtns.length) return;

  const regionData = {
    'nyc-1': { title: 'New York (nyc-1)', ping: '4ms', nodes: '24 MicroVM Nodes', anycast: 'AS-13335 (BGP Anycast)', bw: '80 Gbps Symmetrical' },
    'sfo-1': { title: 'San Francisco (sfo-1)', ping: '9ms', nodes: '18 MicroVM Nodes', anycast: 'AS-13335 (BGP Anycast)', bw: '60 Gbps Symmetrical' },
    'fra-1': { title: 'Frankfurt Core (fra-1)', ping: '12ms', nodes: '24 MicroVM Nodes', anycast: 'AS-13335 (BGP Anycast)', bw: '80 Gbps Symmetrical' },
    'lon-1': { title: 'London Gateway (lon-1)', ping: '14ms', nodes: '16 MicroVM Nodes', anycast: 'AS-13335 (BGP Anycast)', bw: '60 Gbps Symmetrical' },
    'bom-1': { title: 'Mumbai Gateway (bom-1)', ping: '16ms', nodes: '12 MicroVM Nodes', anycast: 'AS-13335 (BGP Anycast)', bw: '40 Gbps Symmetrical' },
    'sin-1': { title: 'Singapore Core (sin-1)', ping: '18ms', nodes: '20 MicroVM Nodes', anycast: 'AS-13335 (BGP Anycast)', bw: '60 Gbps Symmetrical' },
    'tyo-1': { title: 'Tokyo Gateway (tyo-1)', ping: '22ms', nodes: '16 MicroVM Nodes', anycast: 'AS-13335 (BGP Anycast)', bw: '60 Gbps Symmetrical' },
    'syd-1': { title: 'Sydney Gateway (syd-1)', ping: '28ms', nodes: '12 MicroVM Nodes', anycast: 'AS-13335 (BGP Anycast)', bw: '40 Gbps Symmetrical' }
  };

  regionBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const code = btn.getAttribute('data-region');
      if (!code || !regionData[code]) return;

      regionBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const data = regionData[code];
      if (panelTitle) panelTitle.textContent = data.title;
      if (panelPing) panelPing.textContent = data.ping + ' Latency';
      if (panelNodes) panelNodes.textContent = data.nodes;
      if (panelAnycast) panelAnycast.textContent = data.anycast;
      if (panelBw) panelBw.textContent = data.bw;
    });
  });
}

/* --------------------------------------------------------------------------
   10. Console Interactive Enhancements (Rollback & Logs Filter)
   -------------------------------------------------------------------------- */
function initConsoleActions() {
  const rollbackBtn = document.getElementById('btn-simulate-rollback');
  const rollbackBanner = document.getElementById('rollback-banner');
  const activeRevSpan = document.querySelector('.dep-meta-row .dep-unit:first-child .d-v');
  const logFilterBtns = document.querySelectorAll('.log-filter-btn');
  const logRows = document.querySelectorAll('.dark-terminal-log .log-row');

  if (rollbackBtn && rollbackBanner) {
    rollbackBtn.addEventListener('click', () => {
      rollbackBanner.classList.remove('hidden');
      if (activeRevSpan) activeRevSpan.textContent = 'dep_08e2c1a4 (Rolled Back)';
      rollbackBtn.textContent = 'Rollback Applied ✔';
      rollbackBtn.disabled = true;

      setTimeout(() => {
        rollbackBanner.classList.add('hidden');
        rollbackBtn.disabled = false;
        rollbackBtn.textContent = 'Rollback';
      }, 5000);
    });
  }

  // Log filter
  logFilterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const filter = btn.getAttribute('data-filter');
      logFilterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      logRows.forEach(row => {
        if (!filter || filter === 'all') {
          row.style.display = 'flex';
        } else if (filter === 'info' && row.querySelector('.log-badge-info')) {
          row.style.display = 'flex';
        } else if (filter === 'ok' && row.querySelector('.log-badge-ok')) {
          row.style.display = 'flex';
        } else {
          row.style.display = 'none';
        }
      });
    });
  });
}

/* --------------------------------------------------------------------------
   11. Interactive hawkra.yaml Config Builder
   -------------------------------------------------------------------------- */
function initConfigBuilder() {
  const chips = document.querySelectorAll('.cfg-chip');
  const configPaneCode = document.querySelector('#code-config code');

  if (!chips.length || !configPaneCode) return;

  function rebuildYaml() {
    let scaleZero = document.querySelector('.cfg-chip[data-cfg="scale_zero"]')?.classList.contains('active');
    let tlsStrict = document.querySelector('.cfg-chip[data-cfg="tls_13"]')?.classList.contains('active');
    let multiReg = document.querySelector('.cfg-chip[data-cfg="multi_reg"]')?.classList.contains('active');
    let secrets = document.querySelector('.cfg-chip[data-cfg="secrets"]')?.classList.contains('active');

    let yaml = `<span class="t-comment"># hawkra.yaml — Declarative Platform Schema</span>\n` +
      `<span class="t-key">version</span>: <span class="t-val">"1.0"</span>\n` +
      `<span class="t-key">project</span>: <span class="t-val">"production-gateway"</span>\n\n` +
      `<span class="t-key">service</span>:\n` +
      `  <span class="t-key">runtime</span>: <span class="t-val">"node20"</span>\n` +
      `  <span class="t-key">entrypoint</span>: <span class="t-val">"dist/server.js"</span>\n` +
      `  <span class="t-key">memory</span>: <span class="t-val">256MB</span>\n\n` +
      `<span class="t-key">scaling</span>:\n` +
      `  <span class="t-key">min_instances</span>: <span class="t-val">${scaleZero ? '0' : '1'}</span>\n` +
      `  <span class="t-key">max_instances</span>: <span class="t-val">25</span>\n` +
      `  <span class="t-key">concurrency_target</span>: <span class="t-val">250</span>\n`;

    if (tlsStrict || multiReg) {
      yaml += `\n<span class="t-key">ingress</span>:\n`;
      if (tlsStrict) yaml += `  <span class="t-key">tls_version</span>: <span class="t-val">"1.3"</span>\n`;
      if (multiReg) yaml += `  <span class="t-key">regions</span>: <span class="t-val">["nyc-1", "fra-1", "sin-1"]</span>\n`;
    }

    if (secrets) {
      yaml += `\n<span class="t-key">security</span>:\n` +
        `  <span class="t-key">vault_encryption</span>: <span class="t-val">"aes-gcm-256"</span>\n` +
        `  <span class="t-key">mtls_internal</span>: <span class="t-val">true</span>\n`;
    }

    configPaneCode.innerHTML = yaml;
  }

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chip.classList.toggle('active');
      rebuildYaml();
    });
  });
}

/* --------------------------------------------------------------------------
   12. Dynamic Copyright Year
   -------------------------------------------------------------------------- */
function updateFooterYear() {
  const yearEl = document.getElementById('year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
}

/* --------------------------------------------------------------------------
   13. Remade Interactive Onboarding Engine (/get-started)
   -------------------------------------------------------------------------- */
function initGetStartedLaunchpad() {
  // A. Tab Switcher
  const tabBtns = document.querySelectorAll('.ob-tab-btn');
  const tabPanes = document.querySelectorAll('.ob-tab-pane');

  if (tabBtns.length && tabPanes.length) {
    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const targetId = btn.getAttribute('data-tab');
        if (!targetId) return;

        tabBtns.forEach(b => {
          b.classList.remove('active');
          b.setAttribute('aria-selected', 'false');
        });
        btn.classList.add('active');
        btn.setAttribute('aria-selected', 'true');

        tabPanes.forEach(pane => {
          if (pane.id === targetId) {
            pane.classList.add('active');
          } else {
            pane.classList.remove('active');
          }
        });
      });
    });
  }

  // B. Interactive Stack Configurator & Command Generator
  const stackTiles = document.querySelectorAll('.stack-tile-btn');
  const regionPills = document.querySelectorAll('#region-pills .opt-pill-btn');
  const tierPills = document.querySelectorAll('#tier-pills .opt-pill-btn');
  const codeOutput = document.getElementById('lp-code-output');
  const footStack = document.getElementById('lp-foot-stack');
  const footSpecs = document.getElementById('lp-foot-specs');

  let currentConfig = {
    runtime: 'node-ts',
    template: 'node-ts',
    runtimeLabel: 'Node.js / TS (v20)',
    region: 'global-anycast',
    tier: '128mb',
    memLabel: '128MB',
    coldBoot: '<15ms'
  };

  const runtimeSpecs = {
    'node-ts': { template: 'node-ts', label: 'Node.js / TS (v20)', coldBoot: '<15ms', file: 'dist/server.js' },
    'go': { template: 'go-service', label: 'Go (v1.22)', coldBoot: '<9ms', file: 'main.go' },
    'rust': { template: 'rust-actix', label: 'Rust (v1.78)', coldBoot: '<6ms', file: 'src/main.rs' },
    'python': { template: 'fastapi', label: 'Python (v3.12)', coldBoot: '<20ms', file: 'app/main.py' },
    'docker': { template: '--dockerfile', label: 'OCI Container', coldBoot: '<25ms', file: 'Dockerfile' }
  };

  const tierSpecs = {
    '128mb': { mem: '128MB', boot: '<12ms' },
    '256mb': { mem: '256MB', boot: '<15ms' },
    '512mb': { mem: '512MB', boot: '<18ms' }
  };

  function updateGeneratedCommand() {
    if (!codeOutput) return;

    const rt = runtimeSpecs[currentConfig.runtime] || runtimeSpecs['node-ts'];
    const tr = tierSpecs[currentConfig.tier] || tierSpecs['128mb'];

    let initLine = rt.template.startsWith('--') 
      ? `hawkra init ${rt.template}`
      : `hawkra init --template=${rt.template}`;

    let code = `<span class="t-comment"># 1. Install Hawkra CLI</span>\n` +
      `<span class="t-prompt">$</span> npm i -g @hawkra/cli\n\n` +
      `<span class="t-comment"># 2. Initialize ${rt.label} starter</span>\n` +
      `<span class="t-prompt">$</span> ${initLine}\n\n` +
      `<span class="t-comment"># 3. Deploy to ${currentConfig.region}</span>\n` +
      `<span class="t-prompt">$</span> hawkra deploy --tier=${currentConfig.tier} --region=${currentConfig.region}`;

    codeOutput.innerHTML = code;

    if (footStack) footStack.textContent = `Runtime: ${rt.label}`;
    if (footSpecs) footSpecs.textContent = `Memory: ${tr.mem} · Cold Boot: ${rt.coldBoot}`;
  }

  stackTiles.forEach(tile => {
    tile.addEventListener('click', () => {
      stackTiles.forEach(t => t.classList.remove('active'));
      tile.classList.add('active');
      currentConfig.runtime = tile.getAttribute('data-runtime') || 'node-ts';
      updateGeneratedCommand();
    });
  });

  regionPills.forEach(pill => {
    pill.addEventListener('click', () => {
      regionPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentConfig.region = pill.getAttribute('data-region') || 'global-anycast';
      updateGeneratedCommand();
    });
  });

  tierPills.forEach(pill => {
    pill.addEventListener('click', () => {
      tierPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentConfig.tier = pill.getAttribute('data-tier') || '128mb';
      updateGeneratedCommand();
    });
  });

  // C. Live Deploy Simulator
  const btnSimDeploy = document.getElementById('btn-simulate-deploy');
  const simOutputLines = document.getElementById('lp-sim-lines');

  if (btnSimDeploy && simOutputLines) {
    let isSimulating = false;

    btnSimDeploy.addEventListener('click', () => {
      if (isSimulating) return;
      isSimulating = true;
      btnSimDeploy.disabled = true;
      btnSimDeploy.innerHTML = '<span>⚡ Deploying MicroVM...</span>';

      const rt = runtimeSpecs[currentConfig.runtime] || runtimeSpecs['node-ts'];
      const tr = tierSpecs[currentConfig.tier] || tierSpecs['128mb'];

      const steps = [
        { time: '0.00s', text: `Analyzing workload configuration (runtime: ${rt.label}, tier: ${tr.mem}, ingress: ${currentConfig.region})...`, color: '#888888' },
        { time: '0.08s', text: `Packaging build directory into deterministic rootfs tarball...`, color: '#aaaaaa' },
        { time: '0.21s', text: `Allocating isolated Linux KVM hardware sandbox (Process PID: ${Math.floor(20000 + Math.random() * 40000)})...`, color: '#cccccc' },
        { time: '0.34s', text: `MicroVM kernel boot finished in ${rt.coldBoot}. Memory bound: ${tr.mem}.`, color: '#10b981' },
        { time: '0.48s', text: `Edge reverse proxy registered via BGP Anycast (AS-13335).`, color: '#cccccc' },
        { time: '0.62s', text: `TLS 1.3 certificate signed and provisioned for domain.`, color: '#10b981' },
        { time: '0.75s', text: `Healthcheck probe GET /healthz responded: HTTP 200 OK (latency 1.1ms).`, color: '#10b981' },
        { time: '0.88s', text: `✔ Live Route: https://${currentConfig.runtime}-workload.hawkra.cloud`, color: '#ffffff', bold: true }
      ];

      simOutputLines.innerHTML = '';
      let stepIndex = 0;

      function renderNextStep() {
        if (stepIndex < steps.length) {
          const step = steps[stepIndex];
          const div = document.createElement('div');
          div.style.cssText = `color: ${step.color}; margin-bottom: 4px; ${step.bold ? 'font-weight: 600;' : ''}`;
          div.innerHTML = `<span style="color: #666666; margin-right: 6px;">[${step.time}]</span>${step.text}`;
          simOutputLines.appendChild(div);
          simOutputLines.scrollTop = simOutputLines.scrollHeight;
          stepIndex++;
          setTimeout(renderNextStep, 220);
        } else {
          isSimulating = false;
          btnSimDeploy.disabled = false;
          btnSimDeploy.innerHTML = '<span>▶ Deploy Successful (Re-run)</span>';
        }
      }

      renderNextStep();
    });
  }

  // D. Live Vanity Slug Input Listener
  const orgSlugInput = document.getElementById('org-name');
  const vanitySlugPreview = document.getElementById('vanity-slug-preview');

  if (orgSlugInput && vanitySlugPreview) {
    orgSlugInput.addEventListener('input', (e) => {
      const sanitized = e.target.value
        .toLowerCase()
        .replace(/[^a-z0-9-]/g, '')
        .substring(0, 32);
      
      vanitySlugPreview.textContent = sanitized || 'your-org';
    });
  }
}



