import { resolve } from 'path';
import { fileURLToPath } from 'url';
import { defineConfig } from 'vite';

const __dirname = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  build: {
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'index.html'),
        product: resolve(__dirname, 'product.html'),
        productDir: resolve(__dirname, 'product/index.html'),
        openSource: resolve(__dirname, 'open-source.html'),
        openSourceDir: resolve(__dirname, 'open-source/index.html'),
        community: resolve(__dirname, 'community.html'),
        communityDir: resolve(__dirname, 'community/index.html'),
        capabilities: resolve(__dirname, 'capabilities.html'),
        capabilitiesDir: resolve(__dirname, 'capabilities/index.html'),
        getStarted: resolve(__dirname, 'get-started.html'),
        getStartedDir: resolve(__dirname, 'get-started/index.html'),
      },
    },
  },
});
